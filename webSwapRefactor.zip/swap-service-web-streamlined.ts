import { Injectable } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { RpcService } from "./rpc.service";
import { SocketService } from "./socket.service";
import { TxsService } from "./txs.service";
import { LoadingService } from "./loading.service";
import { ESounds, SoundsService } from "./sound.service";
import { WalletService } from './wallet.service';
import { WebSwapCacheService } from './web-swap-cache.service';
import { StreamlinedWebSwapper } from 'src/app/utils/swapper/streamlined-web-swapper';
import { ISpotTradeProps, IFuturesTradeProps, ETradeType } from 'src/app/utils/swapper/common';
import { Observable } from "rxjs";

interface ITradeInfo {
    buyer: any;
    seller: any;
    props: ISpotTradeProps | IFuturesTradeProps;
    type: string;
}

interface IChannelSwapData {
    tradeInfo: ITradeInfo;
    unfilled?: any;
    isBuyer: boolean;
}

/**
 * SwapService - Streamlined Web 2-3 Round Trip Flow
 * 
 * KEY OPTIMIZATIONS FOR WEB:
 * - Batch data fetches via cacheService.batchPrepareSwap()
 * - Multisig cached indefinitely
 * - UTXOs cached 30s, refreshed via WS subscription
 * - Block height cached 15s, auto-refreshed
 * - Channel balances skip commit tx entirely
 * 
 * FLOW:
 *   STEP 1 (Seller): Batch fetch -> commit -> build PSBT -> sign if taker
 *   STEP 2 (Buyer): Verify -> RBF check -> commit -> sign -> finalize if taker signed
 *   STEP 3 (Seller if maker): RBF check -> sign -> finalize -> broadcast
 */
@Injectable({
    providedIn: 'root',
})
export class SwapService {
    private activeSwaps = new Map<string, StreamlinedWebSwapper>();

    constructor(
        private socketService: SocketService,
        private rpcService: RpcService,
        private txsService: TxsService,
        private toastrService: ToastrService,
        private loadingService: LoadingService,
        private soundsService: SoundsService,
        private walletService: WalletService,
        private cacheService: WebSwapCacheService
    ) {}

    /**
     * Initialize swap service with WebSocket
     */
    async onInit(swapConfig: IChannelSwapData, socket: Observable<any>): Promise<void> {
        console.log('[SwapService] New channel swap:', JSON.stringify(swapConfig));
        
        // Initialize cache with WS if not already done
        if (this.socketService.ws) {
            await this.cacheService.onInit(this.socketService.ws);
        }

        const res = await this.executeSwap(swapConfig, socket);

        if (!res || res.error || !res.data?.txid) {
            this.toastrService.error(res?.error || 'Unknown Error', 'Trade Error');
        } else {
            this.soundsService.playSound(ESounds.TRADE_COMPLETED);
            this.toastrService.success('Trade Completed', res.data.txid, { timeOut: 3000 });
        }
    }

    /**
     * Execute swap using streamlined flow
     */
    private async executeSwap(swapConfig: IChannelSwapData, socket: Observable<any>): Promise<{ data?: { txid: string }; error?: string }> {
        const { tradeInfo, isBuyer } = swapConfig;
        const { buyer, seller, props, type } = tradeInfo;

        // Generate trade UUID
        const tradeUUID = `${buyer?.uuid || 'b'}-${seller?.uuid || 's'}-${Date.now()}`;

        // Check for duplicate
        if (this.activeSwaps.has(tradeUUID)) {
            console.warn('[SwapService] Duplicate swap:', tradeUUID);
            return { error: 'Duplicate swap' };
        }

        // Determine my info vs counterparty
        const myInfo = isBuyer ? buyer : seller;
        const cpInfo = isBuyer ? seller : buyer;

        // Create streamlined swapper
        const swapper = new StreamlinedWebSwapper(
            type as ETradeType,
            props,
            myInfo,
            cpInfo,
            isBuyer,
            socket,
            this.txsService,
            this.toastrService,
            this.walletService,
            this.rpcService,
            this.socketService,
            this.cacheService,
            tradeUUID
        );

        // Track active swap
        this.activeSwaps.set(tradeUUID, swapper);

        // Subscribe to events for UI
        swapper.eventSubs$.subscribe(({ eventName }) => {
            this.toastrService.info(eventName, 'Trade Progress', { timeOut: 2000 });
        });

        try {
            const result = await swapper.onReady();
            return result;
        } finally {
            this.activeSwaps.delete(tradeUUID);
            swapper.cleanup();
        }
    }

    /**
     * Process WebSocket messages for cache updates
     * Call this from socket.service when relevant events arrive
     */
    processWsMessage(event: string, data: any): void {
        this.cacheService.processWsMessage(event, data);
    }

    /**
     * Cancel an active swap
     */
    cancelSwap(tradeUUID: string): void {
        const swapper = this.activeSwaps.get(tradeUUID);
        if (swapper) {
            swapper.cleanup();
            this.activeSwaps.delete(tradeUUID);
        }
    }

    /**
     * Get cache statistics
     */
    getCacheStats() {
        return this.cacheService.getStats();
    }

    /**
     * Get active swap count
     */
    getActiveSwapCount(): number {
        return this.activeSwaps.size;
    }
}
