import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { WalletService } from './wallet.service';
import { RpcService, ENetwork } from './rpc.service';
import { ENDPOINTS } from 'src/environments/endpoints.conf';
import axios from 'axios';

/**
 * WebSwapCacheService - Aggressive caching for web swap operations
 * 
 * CACHING STRATEGY:
 * - Multisig addresses: Cached indefinitely by pubkey pair
 * - Block height: Cached 15s, auto-refreshed via WS subscription
 * - UTXOs: Cached per address, invalidated on tx broadcast or WS update
 * - Token balances: Cached per address, refreshed via WS subscription
 * - Channel balances: Cached per multisig, updated on trades
 * 
 * WS SUBSCRIPTIONS (server must support):
 * - 'block' -> new block height
 * - 'utxo:update' -> UTXO changes for subscribed addresses
 * - 'balance:update' -> Token balance changes
 * - 'channel:update' -> Channel balance changes
 */

interface IMultisigCache {
    address: string;
    redeemScript: string;
    scriptPubKey?: string;
    createdAt: number;
}

interface IUtxoCache {
    utxos: any[];
    updatedAt: number;
}

interface ITokenBalanceCache {
    balances: any[];
    updatedAt: number;
}

interface IChannelBalance {
    myShare: number;
    cpShare: number;
    propertyId: number;
    updatedAt: number;
}

@Injectable({ providedIn: 'root' })
export class WebSwapCacheService {
    // Multisig cache - keyed by sorted pubkey pair
    private multisigCache = new Map<string, IMultisigCache>();
    
    // UTXO cache - keyed by address
    private utxoCache = new Map<string, IUtxoCache>();
    
    // Token balance cache - keyed by address
    private tokenBalanceCache = new Map<string, ITokenBalanceCache>();
    
    // Channel balance cache - keyed by multisigAddress:propertyId
    private channelCache = new Map<string, IChannelBalance>();
    
    // Block height - single value
    private _blockHeight = 0;
    private _blockHeightUpdatedAt = 0;
    
    // Column prediction cache - keyed by multisig:addr1:addr2
    private columnCache = new Map<string, 'A' | 'B'>();
    
    // Margin calculation cache - keyed by contractId:amount:price
    private marginCache = new Map<string, { initMargin: number; collateral: number }>();
    
    // Observables for reactive updates
    public blockHeight$ = new BehaviorSubject<number>(0);
    public utxoUpdates$ = new Subject<{ address: string; utxos: any[] }>();
    
    // TTLs
    private readonly BLOCK_HEIGHT_TTL = 15_000;
    private readonly UTXO_TTL = 30_000;
    private readonly TOKEN_BALANCE_TTL = 30_000;
    
    // WebSocket reference for subscriptions
    private ws: WebSocket | null = null;
    private subscribedAddresses = new Set<string>();

    constructor(
        private walletService: WalletService,
        private rpcService: RpcService
    ) {}

    get relayerUrl(): string {
        const net = this.rpcService.NETWORK;
        if (net && typeof net === 'object' && 'relayerUrl' in net) {
            return (net as any).relayerUrl;
        }
        const key = String(net) as ENetwork;
        if (key === ENetwork.LTCTEST) {
            return ENDPOINTS.LTCTEST.relayerUrl;
        }
        return ENDPOINTS.LTC.relayerUrl;
    }

    get blockHeight(): number {
        return this._blockHeight;
    }

    // === INITIALIZATION ===

    /**
     * Initialize cache and set up WebSocket subscriptions
     */
    async onInit(ws: WebSocket): Promise<void> {
        this.ws = ws;
        
        // Set up WS message handler for cache updates
        this.setupWsSubscriptions();
        
        // Initial block height fetch
        await this.refreshBlockHeight();
        
        // Start background refresh
        setInterval(() => this.refreshBlockHeight(), this.BLOCK_HEIGHT_TTL);
        
        console.log('[WebSwapCache] Initialized');
    }

    /**
     * Subscribe to WebSocket events for cache invalidation
     */
    private setupWsSubscriptions(): void {
        if (!this.ws) return;

        // We need to handle messages that come through the existing socket
        // The actual subscription happens in SocketService, we just process updates here
    }

    /**
     * Process incoming WebSocket message for cache updates
     * Call this from SocketService when relevant events arrive
     */
    processWsMessage(event: string, data: any): void {
        switch (event) {
            case 'block':
                this._blockHeight = data.height || data.blocks || data;
                this._blockHeightUpdatedAt = Date.now();
                this.blockHeight$.next(this._blockHeight);
                break;
                
            case 'utxo:update':
                if (data.address) {
                    this.utxoCache.set(data.address, {
                        utxos: data.utxos || [],
                        updatedAt: Date.now()
                    });
                    this.utxoUpdates$.next({ address: data.address, utxos: data.utxos });
                }
                break;
                
            case 'balance:update':
                if (data.address) {
                    this.tokenBalanceCache.set(data.address, {
                        balances: data.balances || [],
                        updatedAt: Date.now()
                    });
                }
                break;
                
            case 'channel:update':
                if (data.multisig && data.propertyId !== undefined) {
                    const key = `${data.multisig}:${data.propertyId}`;
                    this.channelCache.set(key, {
                        myShare: data.myShare || 0,
                        cpShare: data.cpShare || 0,
                        propertyId: data.propertyId,
                        updatedAt: Date.now()
                    });
                }
                break;
        }
    }

    // === BLOCK HEIGHT ===

    async getBlockHeight(): Promise<number> {
        if (Date.now() - this._blockHeightUpdatedAt < this.BLOCK_HEIGHT_TTL && this._blockHeight > 0) {
            return this._blockHeight;
        }
        return this.refreshBlockHeight();
    }

    private async refreshBlockHeight(): Promise<number> {
        try {
            const res = await axios.get(`${this.relayerUrl}/chain/info`);
            const blocks = res.data?.blocks || res.data?.height;
            if (blocks) {
                this._blockHeight = blocks;
                this._blockHeightUpdatedAt = Date.now();
                this.blockHeight$.next(this._blockHeight);
            }
            return this._blockHeight;
        } catch (err) {
            console.warn('[WebSwapCache] Failed to refresh block height');
            return this._blockHeight;
        }
    }

    // === MULTISIG MANAGEMENT ===

    private getMultisigKey(pubkeys: [string, string]): string {
        return [...pubkeys].sort().join(':');
    }

    async getOrCreateMultisig(pubkeys: [string, string]): Promise<IMultisigCache> {
        const key = this.getMultisigKey(pubkeys);
        const cached = this.multisigCache.get(key);
        
        if (cached) {
            return cached;
        }
        
        // Create via wallet extension
        const result = await this.walletService.addMultisig(2, pubkeys);
        if (!result?.address || !result?.redeemScript) {
            throw new Error('Failed to create multisig');
        }
        
        const msData: IMultisigCache = {
            address: result.address,
            redeemScript: result.redeemScript,
            scriptPubKey: result.scriptPubKey,
            createdAt: Date.now()
        };
        
        this.multisigCache.set(key, msData);
        return msData;
    }

    verifyMultisig(pubkeys: [string, string], expectedRedeemScript: string): boolean {
        const key = this.getMultisigKey(pubkeys);
        const cached = this.multisigCache.get(key);
        return cached?.redeemScript === expectedRedeemScript;
    }

    // === UTXO MANAGEMENT ===

    async getUtxos(address: string, pubkey?: string): Promise<any[]> {
        const cached = this.utxoCache.get(address);
        
        if (cached && (Date.now() - cached.updatedAt) < this.UTXO_TTL) {
            return cached.utxos;
        }
        
        try {
            const payload = pubkey ? { pubkey } : {};
            const res = await axios.post(`${this.relayerUrl}/address/utxo/${address}`, payload);
            const utxos = res.data || [];
            
            this.utxoCache.set(address, {
                utxos,
                updatedAt: Date.now()
            });
            
            // Subscribe to updates for this address
            this.subscribeToAddress(address);
            
            return utxos;
        } catch (err) {
            console.warn(`[WebSwapCache] Failed to fetch UTXOs for ${address}`);
            return cached?.utxos || [];
        }
    }

    /**
     * Invalidate UTXO cache for an address (after broadcasting tx)
     */
    invalidateUtxos(address: string): void {
        this.utxoCache.delete(address);
    }

    /**
     * Subscribe to UTXO updates for an address via WebSocket
     */
    private subscribeToAddress(address: string): void {
        if (this.subscribedAddresses.has(address)) return;
        
        if (this.ws?.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                event: 'subscribe:address',
                data: { address }
            }));
            this.subscribedAddresses.add(address);
        }
    }

    // === TOKEN BALANCE ===

    async getTokenBalances(address: string): Promise<any[]> {
        const cached = this.tokenBalanceCache.get(address);
        
        if (cached && (Date.now() - cached.updatedAt) < this.TOKEN_BALANCE_TTL) {
            return cached.balances;
        }
        
        try {
            const res = await axios.get(`${this.relayerUrl}/address/balance/${address}`);
            const balances = res.data || [];
            
            this.tokenBalanceCache.set(address, {
                balances,
                updatedAt: Date.now()
            });
            
            return balances;
        } catch (err) {
            console.warn(`[WebSwapCache] Failed to fetch token balances for ${address}`);
            return cached?.balances || [];
        }
    }

    /**
     * Get specific token balance
     */
    async getTokenBalance(address: string, propertyId: number): Promise<{ available: number; channel: number }> {
        const balances = await this.getTokenBalances(address);
        const token = balances.find((t: any) => t.propertyId === propertyId || t.propertyid === propertyId);
        return {
            available: token?.available || 0,
            channel: token?.channel || 0
        };
    }

    // === CHANNEL BALANCE ===

    getChannelBalance(multisigAddress: string, propertyId: number): IChannelBalance | undefined {
        const key = `${multisigAddress}:${propertyId}`;
        return this.channelCache.get(key);
    }

    setChannelBalance(multisigAddress: string, propertyId: number, myShare: number, cpShare: number): void {
        const key = `${multisigAddress}:${propertyId}`;
        this.channelCache.set(key, {
            myShare,
            cpShare,
            propertyId,
            updatedAt: Date.now()
        });
    }

    /**
     * Check if we can use channel balance instead of wallet balance
     */
    canUseChannelBalance(multisigAddress: string, propertyId: number, amount: number): boolean {
        const channel = this.getChannelBalance(multisigAddress, propertyId);
        return channel !== undefined && channel.myShare >= amount;
    }

    // === COLUMN PREDICTION ===

    getCachedColumn(multisig: string, addr1: string, addr2: string): 'A' | 'B' | null {
        const key = `${multisig}:${addr1}:${addr2}`;
        return this.columnCache.get(key) || null;
    }

    cacheColumn(multisig: string, addr1: string, addr2: string, column: 'A' | 'B'): void {
        const key = `${multisig}:${addr1}:${addr2}`;
        this.columnCache.set(key, column);
    }

    // === MARGIN CALCULATION ===

    getCachedMargin(contractId: number, amount: number, price: number): { initMargin: number; collateral: number } | null {
        const key = `${contractId}:${amount}:${price}`;
        return this.marginCache.get(key) || null;
    }

    cacheMargin(contractId: number, amount: number, price: number, margin: { initMargin: number; collateral: number }): void {
        const key = `${contractId}:${amount}:${price}`;
        this.marginCache.set(key, margin);
    }

    // === BATCH OPERATIONS ===

    /**
     * Batch prepare for a swap - fetches all needed data in parallel
     * This is the key optimization for web - one HTTP call instead of many
     */
    async batchPrepareSwap(params: {
        myAddress: string;
        myPubkey: string;
        cpPubkey: string;
        propertyId: number;
        amount: number;
    }): Promise<{
        multisig: IMultisigCache;
        utxos: any[];
        tokenBalance: { available: number; channel: number };
        blockHeight: number;
        canUseChannel: boolean;
    }> {
        const pubkeys: [string, string] = [params.myPubkey, params.cpPubkey];
        
        // Parallel fetches
        const [multisig, utxos, tokenBalance, blockHeight] = await Promise.all([
            this.getOrCreateMultisig(pubkeys),
            this.getUtxos(params.myAddress, params.myPubkey),
            this.getTokenBalance(params.myAddress, params.propertyId),
            this.getBlockHeight()
        ]);
        
        const canUseChannel = this.canUseChannelBalance(multisig.address, params.propertyId, params.amount);
        
        return {
            multisig,
            utxos,
            tokenBalance,
            blockHeight,
            canUseChannel
        };
    }

    // === CACHE MANAGEMENT ===

    clearAll(): void {
        this.multisigCache.clear();
        this.utxoCache.clear();
        this.tokenBalanceCache.clear();
        this.channelCache.clear();
        this.columnCache.clear();
        this.marginCache.clear();
    }

    getStats(): { multisigs: number; utxos: number; balances: number; channels: number } {
        return {
            multisigs: this.multisigCache.size,
            utxos: this.utxoCache.size,
            balances: this.tokenBalanceCache.size,
            channels: this.channelCache.size
        };
    }
}
