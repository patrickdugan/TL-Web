/**
 * Streamlined Web Swapper - 2-3 Round Trip Protocol
 * 
 * Optimized for web where all data goes through relayer HTTP calls.
 * Uses aggressive caching and batched operations.
 * 
 * FLOW:
 *   STEP 1 (Seller initiates):
 *     - Batch fetch: multisig + UTXOs + balances + blockHeight
 *     - Build + send commit (or use channel balance)
 *     - Build trade PSBT
 *     - If taker: sign via wallet extension
 *     - Emit to buyer
 * 
 *   STEP 2 (Buyer responds):
 *     - Verify multisig (cached)
 *     - RBF check via relayer
 *     - Build + send commit (or use channel)
 *     - Sign PSBT via wallet extension
 *     - If seller was taker: finalize + broadcast, done
 *     - Else: return for final sig
 * 
 *   STEP 3 (Only if seller is maker):
 *     - RBF check
 *     - Sign + finalize + broadcast
 */

import { Observable, Subject, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { TxsService, IUTXO, IBuildLTCITTxConfig } from 'src/app/@core/services/txs.service';
import { WalletService } from 'src/app/@core/services/wallet.service';
import { RpcService, ENetwork } from 'src/app/@core/services/rpc.service';
import { SocketService } from 'src/app/@core/services/socket.service';
import { WebSwapCacheService } from 'src/app/@core/services/web-swap-cache.service';
import { ENDPOINTS } from 'src/environments/endpoints.conf';
import { IMSChannelData, SwapEvent, IBuyerSellerInfo, IFuturesTradeProps, ISpotTradeProps, ETradeType } from './common';
import { ENCODER } from '../payloads/encoder';
import axios from 'axios';

interface IStep1Data {
    tradeUUID: string;
    multisig: IMSChannelData;
    commitTxId?: string;
    commitUtxo?: IUTXO;
    psbtHex: string;
    isSigned: boolean;
    isMaker: boolean;
    useChannelBalance: boolean;
}

interface IStep2Data {
    tradeUUID: string;
    psbtHex: string;
    commitTxId?: string;
    commitUtxo?: IUTXO;
    needsFinalSignature: boolean;
    finalTxId?: string;
}

export class StreamlinedWebSwapper {
    public eventSubs$ = new Subject<any>();
    
    protected multySigChannelData: IMSChannelData | null = null;
    protected readyRes: ((value: any) => void) | null = null;
    protected swapSub: Subscription | null = null;
    
    private tradeStartTime: number;

    constructor(
        protected typeTrade: ETradeType,
        protected tradeInfo: ISpotTradeProps | IFuturesTradeProps,
        protected myInfo: IBuyerSellerInfo,
        protected cpInfo: IBuyerSellerInfo,
        protected isBuyer: boolean,
        protected socket: Observable<any>,
        protected txsService: TxsService,
        protected toastrService: ToastrService,
        protected walletService: WalletService,
        protected rpcService: RpcService,
        protected socketService: SocketService,
        protected cacheService: WebSwapCacheService,
        protected tradeUUID: string
    ) {
        this.tradeStartTime = Date.now();
        this.setupEventHandlers();
    }

    protected get isMaker(): boolean {
        const props = this.tradeInfo as any;
        const sellerIsMaker = props.sellerIsMaker ?? false;
        return this.isBuyer ? !sellerIsMaker : sellerIsMaker;
    }

    protected get isInitiator(): boolean {
        return !this.isBuyer; // Seller initiates
    }

    protected get relayerUrl(): string {
        const net = this.rpcService.NETWORK;
        if (net && typeof net === 'object' && 'relayerUrl' in net) {
            return (net as any).relayerUrl;
        }
        const key = String(net) as ENetwork;
        return key === ENetwork.LTCTEST ? ENDPOINTS.LTCTEST.relayerUrl : ENDPOINTS.LTC.relayerUrl;
    }

    protected logTime(stage: string): void {
        console.log(`[WebSwap:${this.tradeUUID.slice(0,8)}] ${stage}: ${Date.now() - this.tradeStartTime}ms`);
    }

    // === PUBLIC API ===

    onReady(): Promise<{ data?: { txid: string }; error?: string }> {
        return new Promise((resolve) => {
            this.readyRes = resolve;
            setTimeout(() => this.terminate('Timeout'), 90000);
            
            if (this.isInitiator) {
                this.initiateStep1();
            }
        });
    }

    cleanup(): void {
        this.swapSub?.unsubscribe();
        this.swapSub = null;
    }

    protected terminate(reason: string): void {
        this.logTime(`TERMINATED: ${reason}`);
        this.socketService.send(`${this.myInfo.socketId}::swap`, new SwapEvent('TERMINATE', this.myInfo.socketId, { reason, tradeUUID: this.tradeUUID }).toJSON());
        this.cleanup();
        this.readyRes?.({ error: reason });
    }

    protected complete(txid: string): void {
        this.logTime(`COMPLETE: ${txid}`);
        this.toastrService.success('Trade completed', txid);
        this.cleanup();
        this.readyRes?.({ data: { txid } });
    }

    // === EVENT HANDLING ===

    protected setupEventHandlers(): void {
        const eventName = `${this.cpInfo.socketId}::swap`;
        
        this.swapSub = this.socket
            .pipe(filter(({ event }) => event === eventName))
            .subscribe((payload) => {
                const eventData = payload.data?.data || payload.data;
                if (eventData?.tradeUUID && eventData.tradeUUID !== this.tradeUUID) return;

                const innerEvent = eventData?.eventName || payload.data?.eventName;
                const innerData = eventData?.data || eventData;

                this.eventSubs$.next({ eventName: innerEvent, data: innerData });

                switch (innerEvent) {
                    case 'STEP1':
                        this.handleStep1(innerData);
                        break;
                    case 'STEP2':
                        this.handleStep2(innerData);
                        break;
                    case 'COMPLETE':
                        this.complete(innerData?.txid || innerData);
                        break;
                    case 'TERMINATE':
                        this.cleanup();
                        this.readyRes?.({ error: innerData?.reason || 'Terminated by peer' });
                        break;
                }
            });
    }

    // === STEP 1: SELLER INITIATES ===

    protected async initiateStep1(): Promise<void> {
        this.logTime('STEP1: Initiating');
        try {
            const props = this.tradeInfo as any;
            const { propertyId, amount } = this.getMyCommitRequirements();

            // Batch fetch all needed data
            const prepData = await this.cacheService.batchPrepareSwap({
                myAddress: this.myInfo.keypair.address,
                myPubkey: this.myInfo.keypair.pubkey,
                cpPubkey: this.cpInfo.keypair.pubkey,
                propertyId,
                amount
            });

            this.multySigChannelData = prepData.multisig as IMSChannelData;
            const expiryBlock = prepData.blockHeight + 10;

            // Determine if we can use channel balance
            let commitTxId: string | undefined;
            let commitUtxo: IUTXO | undefined;
            const useChannelBalance = prepData.canUseChannel;

            if (!useChannelBalance) {
                // Build and send commit tx
                const commitResult = await this.buildAndSendCommit(propertyId, amount, prepData.utxos);
                commitTxId = commitResult.txid;
                commitUtxo = commitResult.utxo;
            }

            // Get column info
            const columnInfo = await this.getColumnInfo();

            // Build trade PSBT
            const psbtResult = await this.buildTradePsbt(commitUtxo, expiryBlock, columnInfo);

            // If taker, sign now
            let psbtHex = psbtResult.psbtHex;
            let isSigned = false;

            if (!this.isMaker) {
                const signedPsbt = await this.walletService.signPsbt(psbtHex, { autoFinalize: false });
                psbtHex = signedPsbt;
                isSigned = true;
            }

            // Emit to buyer
            const step1Data: IStep1Data = {
                tradeUUID: this.tradeUUID,
                multisig: this.multySigChannelData,
                commitTxId,
                commitUtxo,
                psbtHex,
                isSigned,
                isMaker: this.isMaker,
                useChannelBalance
            };

            this.socketService.send(
                `${this.myInfo.socketId}::swap`,
                new SwapEvent('STEP1', this.myInfo.socketId, step1Data).toJSON()
            );

            this.logTime('STEP1: Complete');
        } catch (err: any) {
            this.terminate(`Step1: ${err.message}`);
        }
    }

    // === STEP 2: BUYER RESPONDS ===

    protected async handleStep1(data: IStep1Data): Promise<void> {
        if (!this.isBuyer) return;
        
        this.logTime('STEP2: Processing');
        try {
            const { multisig, commitTxId, psbtHex, isSigned, useChannelBalance } = data;

            // Verify multisig
            const pubkeys: [string, string] = this.getPubkeyOrder();
            if (!this.cacheService.verifyMultisig(pubkeys, multisig.redeemScript)) {
                // Try creating it ourselves to verify
                const ourMs = await this.cacheService.getOrCreateMultisig(pubkeys);
                if (ourMs.redeemScript !== multisig.redeemScript) {
                    throw new Error('Multisig verification failed');
                }
            }
            this.multySigChannelData = multisig;

            // RBF check on seller's commit
            if (commitTxId && !useChannelBalance) {
                await this.checkRbf(commitTxId);
            }

            // Get our requirements
            const { propertyId, amount } = this.getMyCommitRequirements();

            // Check our balance
            const canUseChannel = this.cacheService.canUseChannelBalance(multisig.address, propertyId, amount);
            let myCommitTxId: string | undefined;
            let myCommitUtxo: IUTXO | undefined;

            if (!canUseChannel) {
                const utxos = await this.cacheService.getUtxos(this.myInfo.keypair.address, this.myInfo.keypair.pubkey);
                const commitResult = await this.buildAndSendCommit(propertyId, amount, utxos);
                myCommitTxId = commitResult.txid;
                myCommitUtxo = commitResult.utxo;
            }

            // Sign PSBT
            const signedPsbt = await this.walletService.signPsbt(psbtHex, { autoFinalize: isSigned });

            if (isSigned) {
                // Seller already signed (taker) - we can finalize and broadcast
                const txid = await this.txsService.sendTxWithSpecRetry(signedPsbt);
                if (!txid?.data) throw new Error('Broadcast failed');

                // Notify seller
                this.socketService.send(
                    `${this.myInfo.socketId}::swap`,
                    new SwapEvent('COMPLETE', this.myInfo.socketId, { txid: txid.data, tradeUUID: this.tradeUUID }).toJSON()
                );

                this.complete(txid.data);
            } else {
                // Seller is maker - needs final signature
                const step2Data: IStep2Data = {
                    tradeUUID: this.tradeUUID,
                    psbtHex: signedPsbt,
                    commitTxId: myCommitTxId,
                    commitUtxo: myCommitUtxo,
                    needsFinalSignature: true
                };

                this.socketService.send(
                    `${this.myInfo.socketId}::swap`,
                    new SwapEvent('STEP2', this.myInfo.socketId, step2Data).toJSON()
                );
            }

            this.logTime('STEP2: Complete');
        } catch (err: any) {
            this.terminate(`Step2: ${err.message}`);
        }
    }

    // === STEP 3: SELLER FINALIZES (if maker) ===

    protected async handleStep2(data: IStep2Data): Promise<void> {
        if (this.isBuyer || !this.isMaker) return;

        this.logTime('STEP3: Finalizing');
        try {
            const { psbtHex, commitTxId } = data;

            // RBF check on buyer's commit
            if (commitTxId) {
                await this.checkRbf(commitTxId);
            }

            // Sign and finalize
            const signedPsbt = await this.walletService.signPsbt(psbtHex, { autoFinalize: true });

            // Broadcast
            const txid = await this.txsService.sendTxWithSpecRetry(signedPsbt);
            if (!txid?.data) throw new Error('Broadcast failed');

            // Notify buyer
            this.socketService.send(
                `${this.myInfo.socketId}::swap`,
                new SwapEvent('COMPLETE', this.myInfo.socketId, { txid: txid.data, tradeUUID: this.tradeUUID }).toJSON()
            );

            this.complete(txid.data);
            this.logTime('STEP3: Complete');
        } catch (err: any) {
            this.terminate(`Step3: ${err.message}`);
        }
    }

    // === HELPERS ===

    protected getPubkeyOrder(): [string, string] {
        const props = this.tradeInfo as any;
        const { propIdDesired, propIdForSale } = props;
        
        // LTC trades: buyer pubkey first
        if (propIdDesired === 0 || propIdForSale === 0) {
            return [this.isBuyer ? this.myInfo.keypair.pubkey : this.cpInfo.keypair.pubkey,
                    this.isBuyer ? this.cpInfo.keypair.pubkey : this.myInfo.keypair.pubkey];
        }
        // Token trades: seller pubkey first
        return [this.isBuyer ? this.cpInfo.keypair.pubkey : this.myInfo.keypair.pubkey,
                this.isBuyer ? this.myInfo.keypair.pubkey : this.cpInfo.keypair.pubkey];
    }

    protected getMyCommitRequirements(): { propertyId: number; amount: number } {
        const props = this.tradeInfo as any;
        
        if (this.typeTrade === ETradeType.FUTURES) {
            return {
                propertyId: props.collateral,
                amount: props.initMargin
            };
        }
        
        // SPOT
        if (this.isBuyer) {
            return { propertyId: props.propIdForSale, amount: props.amountForSale };
        }
        return { propertyId: props.propIdDesired, amount: props.amountDesired };
    }

    protected async getColumnInfo(): Promise<{ iAmColumnA: boolean }> {
        if (!this.multySigChannelData) throw new Error('No multisig');
        
        // Check cache first
        const cached = this.cacheService.getCachedColumn(
            this.multySigChannelData.address,
            this.myInfo.keypair.address,
            this.cpInfo.keypair.address
        );
        
        if (cached) {
            return { iAmColumnA: cached === 'A' };
        }

        // Predict via txsService
        const column = await this.txsService.predictColumn(
            this.multySigChannelData.address,
            this.myInfo.keypair.address,
            this.cpInfo.keypair.address
        );
        
        this.cacheService.cacheColumn(
            this.multySigChannelData.address,
            this.myInfo.keypair.address,
            this.cpInfo.keypair.address,
            column as 'A' | 'B'
        );
        
        return { iAmColumnA: column === 'A' };
    }

    protected async buildAndSendCommit(propertyId: number, amount: number, utxos: any[]): Promise<{ txid: string; utxo: IUTXO }> {
        if (!this.multySigChannelData) throw new Error('No multisig');

        const payload = ENCODER.encodeCommit({
            propertyId,
            amount,
            channelAddress: this.multySigChannelData.address
        });

        const commitResult = await this.txsService.buildSignSendTxGrabUTXO({
            fromKeyPair: { address: this.myInfo.keypair.address },
            toKeyPair: { address: this.multySigChannelData.address },
            payload
        });

        if (commitResult.error || !commitResult.txid || !commitResult.commitUTXO) {
            throw new Error(`Commit failed: ${commitResult.error}`);
        }

        // Invalidate UTXO cache
        this.cacheService.invalidateUtxos(this.myInfo.keypair.address);

        return {
            txid: commitResult.txid,
            utxo: {
                ...commitResult.commitUTXO,
                txid: commitResult.txid,
                scriptPubKey: this.multySigChannelData.scriptPubKey,
                redeemScript: this.multySigChannelData.redeemScript
            } as IUTXO
        };
    }

    protected async buildTradePsbt(commitUtxo: IUTXO | undefined, expiryBlock: number, columnInfo: { iAmColumnA: boolean }): Promise<{ psbtHex: string }> {
        const props = this.tradeInfo as any;
        const { iAmColumnA } = columnInfo;

        // FIXED: columnAIsSeller logic
        // I am SELLER in initiateStep1
        // If I'm column A and I'm seller → columnAIsSeller = 1
        // If I'm column B and I'm seller → columnAIsSeller = 0
        const columnAIsSeller = iAmColumnA ? 1 : 0;

        // columnAIsMaker
        const sellerIsMaker = props.sellerIsMaker ?? false;
        const columnAIsMaker = iAmColumnA ? (sellerIsMaker ? 1 : 0) : (sellerIsMaker ? 0 : 1);

        let payload: string;
        let buildOptions: IBuildLTCITTxConfig;

        if (this.typeTrade === ETradeType.FUTURES) {
            payload = ENCODER.encodeTradeContractChannel({
                contractId: props.contract_id,
                amount: props.amount,
                price: props.price,
                expiryBlock,
                columnAIsSeller,
                insurance: false,
                columnAIsMaker
            });
        } else {
            // SPOT
            const { propIdDesired, propIdForSale, amountDesired, amountForSale } = props;

            if (propIdDesired === 0 || propIdForSale === 0) {
                // LTC trade
                const tokenId = propIdForSale || propIdDesired;
                const tokenAmount = propIdForSale ? amountForSale : amountDesired;
                const satsExpected = propIdDesired === 0 ? amountDesired : amountForSale;

                payload = ENCODER.encodeTradeTokenForUTXO({
                    propertyId: tokenId,
                    amount: tokenAmount,
                    columnA: iAmColumnA ? 1 : 0,
                    satsExpected,
                    tokenOutput: 0,
                    payToAddress: 1
                });
            } else {
                // Token-to-token
                payload = ENCODER.encodeTradeTokensChannel({
                    propertyId1: propIdForSale,
                    propertyId2: propIdDesired,
                    amountOffered1: amountForSale,
                    amountDesired2: amountDesired,
                    expiryBlock,
                    columnAIsOfferer: iAmColumnA ? 1 : 0,
                    columnAIsMaker
                });
            }
        }

        // Determine buyer/seller keypairs based on who we are
        const buyerKeyPair = this.isBuyer ? this.myInfo.keypair : this.cpInfo.keypair;
        const sellerKeyPair = this.isBuyer ? this.cpInfo.keypair : this.myInfo.keypair;

        buildOptions = {
            buyerKeyPair,
            sellerKeyPair,
            commitUTXOs: commitUtxo ? [commitUtxo] : [],
            payload,
            amount: 0
        };

        const result = await this.txsService.buildLTCITTx(buildOptions, 0);
        if (result.error || !result.data?.psbtHex) {
            throw new Error(`Build PSBT failed: ${result.error}`);
        }

        return { psbtHex: result.data.psbtHex };
    }

    protected async checkRbf(txid: string): Promise<void> {
        try {
            const res = await axios.get(`${this.relayerUrl}/tx/${txid}?verbose=true`);
            const vins = res.data?.vin || [];
            const isRbf = vins.some((vin: any) => (vin.sequence >>> 0) < 0xfffffffe);
            if (isRbf) throw new Error('RBF-enabled commit detected');
        } catch (err: any) {
            if (err.message?.includes('RBF')) throw err;
            // If tx not found yet, that's ok - it's in mempool
            console.warn(`[WebSwap] RBF check warning: ${err.message}`);
        }
    }
}
