export * from './algo-trading.component';
```ts
export * from './algo-trading.component';
```ts
export * from './algo-trading.component';