export const safeNumber = (a: number, d: number = 8) => parseFloat((a).toFixed(d));
