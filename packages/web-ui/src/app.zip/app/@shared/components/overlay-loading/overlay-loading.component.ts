import { Component } from '@angular/core';
@Component({
  selector: 'overlay-loading',
  templateUrl: './overlay-loading.component.html',
  styleUrls: ['./overlay-loading.component.scss']
})
export class OverlayLoadingComponent {
  constructor() {}
}
