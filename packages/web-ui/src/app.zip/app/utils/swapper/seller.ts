import { IBuildTxConfig, IUTXO, TxsService } from "src/app/@core/services/txs.service";
import { IMSChannelData, SwapEvent, IBuyerSellerInfo, TClient, IFuturesTradeProps, ISpotTradeProps, ETradeType } from "./common";
import { Swap } from "./swap";
import { ENCODER } from '../payloads/encoder';
import { ToastrService } from "ngx-toastr";
import { WalletService } from 'src/app/@core/services/wallet.service';
import { RpcService, ENetwork } from 'src/app/@core/services/rpc.service'
import { ENDPOINTS } from 'src/environments/endpoints.conf';
import { SocketService } from 'src/app/@core/services/socket.service';
import BigNumber from 'bignumber.js';
import axios from 'axios';
import { Subject, Subscription } from "rxjs";
import { filter } from "rxjs/operators";
import { Observable } from "rxjs";

export class SellSwapper extends Swap {
    private tradeStartTime: number;

    constructor(
        typeTrade: ETradeType,
        tradeInfo: ISpotTradeProps | IFuturesTradeProps,
        sellerInfo: IBuyerSellerInfo,
        buyerInfo: IBuyerSellerInfo,
        socket: Observable<any>,
        txsService: TxsService,
        private toastrService: ToastrService,
        private walletService: WalletService,
        private rpcService: RpcService,
        protected socketService: SocketService,
        tradeUUID: string
    ) {
        super(typeTrade, tradeInfo, sellerInfo, buyerInfo, socket, txsService,socketService,tradeUUID);
        this.handleOnEvents();
        this.tradeStartTime = Date.now();
        this.onReady();
        this.initTrade();
    }

    private logTime(stage: string) {
        const currentTime = Date.now();
        console.log(`Time taken for ${stage}: ${currentTime - this.tradeStartTime} ms`);
    }

    get relayerUrl(): string {
        const net = this.rpcService.NETWORK;
        console.log('[FMS] rpcService.NETWORK =', net, 'typeof →', typeof net);

        // 1) If they in fact passed you an object that _already_ has
        //    a relayerUrl field (e.g. ENDPOINTS.LTCTEST itself),
        //    just use that directly:
        if (net && typeof net === 'object' && 'relayerUrl' in net) {
          // @ts-ignore – we know it has relayerUrl
          const urlFromObj = (net as any).relayerUrl;
          console.log('[FMS] using relayerUrl on NETWORK object →', urlFromObj);
          return urlFromObj;
        }

        // 2) Otherwise stringify it (in case it's a number, enum, etc.)
        const key = String(net) as ENetwork;
        console.log('[FMS] coerced network key →', key);

        // 3) Compare against your enum
        if (key === ENetwork.LTCTEST) {
          const u = ENDPOINTS.LTCTEST.relayerUrl;
          console.log('[FMS] matched LTCTEST →', u);
          return u;
        }

        // 4) Default to mainnet
        const fallback = ENDPOINTS.LTC.relayerUrl;
        console.log('[FMS] defaulting to LTC →', fallback);
        return fallback;
      }

       private handleOnEvents() {
            this.removePreviuesListeners();
            const _eventName = `${this.cpInfo.socketId}::swap`;

            this.swapSub = this.socket
                .pipe(filter(({ event }) => event === _eventName))
                .subscribe((payload: { event: string; data: SwapEvent }) => {
                    // The object RxJS emits looks like: { event: string, data: SwapEvent }
                    const eventData = payload.data;
                    console.log('inside rxjs listener '+JSON.stringify(eventData))
                    if (eventData.data?.tradeUUID && eventData.data.tradeUUID !== this.tradeUUID) {
                        return;
                    }

                    this.eventSubs$.next(eventData);

                    const socketId = eventData.data.socketId;
                    const data = eventData.data.data
                    switch (eventData.data.eventName){
                        case 'TERMINATE_TRADE':
                            this.onTerminateTrade(socketId, data);
                            break;
                        case 'BUYER:STEP2':
                            this.onStep2(socketId);
                            break;
                        case 'BUYER:STEP4':
                            const { psbtHex, commitTxId } = data || {};
                            this.onStep4(socketId, psbtHex, commitTxId);
                            break;
                        case 'BUYER:STEP6':
                            this.onStep6(socketId, data);
                            break;
                    }
                });
        }

    private async initTrade() {
        try {
            let pubKeys = [this.myInfo.keypair.pubkey, this.cpInfo.keypair.pubkey];
            if (this.typeTrade === ETradeType.SPOT && 'propIdDesired' in this.tradeInfo) {
                const { propIdDesired, propIdForSale } = this.tradeInfo;
                if (propIdDesired === 0 || propIdForSale === 0) {
                    pubKeys = [this.cpInfo.keypair.pubkey, this.myInfo.keypair.pubkey];
                }
            }
            const ms = await this.walletService.addMultisig(2, pubKeys);
            console.log('ms '+JSON.stringify(ms)+' pubkeys'+this.myInfo.keypair.pubkey+' '+this.cpInfo.keypair.pubkey)
            if (!ms || !ms.address || !ms.redeemScript) throw new Error('Multisig setup failed');
this.multySigChannelData = ms as IMSChannelData;
            const swapEvent = new SwapEvent('SELLER:STEP1', this.myInfo.socketId, this.multySigChannelData);
            this.socketService.send(`${this.myInfo.socketId}::swap`, swapEvent.toJSON());
        } catch (err: any) {
            this.terminateTrade(`InitTrade: ${err.message}`);
        }
    }

    // PATCHED SELLER onStep2 - Drop-in replacement for seller.ts

private async onStep2(cpId: string) {
    this.logTime('Step 2 Start');
    try {
        if (!this.multySigChannelData?.address || cpId !== this.cpInfo.socketId) {
            throw new Error('Step 2: invalid channel setup or cpId mismatch');
        }

        const fromKeyPair = { address: this.myInfo.keypair.address };
        const toKeyPair = { address: this.multySigChannelData.address };
        let payload: string;

        // Determine column ONCE for the channel
        const columnResult = await this.txsService.predictColumn(
            this.multySigChannelData.address,
            this.myInfo.keypair.address,
            this.cpInfo.keypair.address
        );
        const isA = columnResult === 'A';

        if (this.typeTrade === ETradeType.SPOT && 'propIdDesired' in this.tradeInfo) {
            const { propIdDesired, amountDesired, transfer = false } = this.tradeInfo;

            payload = transfer
                ? ENCODER.encodeTransfer({ 
                    propertyId: propIdDesired, 
                    amount: amountDesired, 
                    isColumnA: isA, 
                    destinationAddr: toKeyPair.address 
                })
                : ENCODER.encodeCommit({ 
                    propertyId: propIdDesired, 
                    amount: amountDesired, 
                    channelAddress: toKeyPair.address 
                });

        } else if (this.typeTrade === ETradeType.FUTURES && 'contract_id' in this.tradeInfo) {
            const { contract_id, amount, price, transfer = false } = this.tradeInfo;

            // Compute margin locally - NOT from trade props
            const { initMargin, collateral } = await this.txsService.computeMargin(
                contract_id,
                amount,
                price
            );

            console.log('computed margin '+initMargin+' '+collateral)

            payload = transfer
                ? ENCODER.encodeTransfer({ 
                    propertyId: collateral, 
                    amount: initMargin, 
                    isColumnA: isA, 
                    destinationAddr: toKeyPair.address 
                })
                : ENCODER.encodeCommit({ 
                    propertyId: collateral, 
                    amount: initMargin, 
                    channelAddress: toKeyPair.address 
                });
        } else {
            throw new Error('Unrecognized trade type');
        }

        const commitTx = await this.txsService.buildSignSendTxGrabUTXO({ 
            fromKeyPair, 
            toKeyPair, 
            payload 
        });
        
        if (commitTx.error || !commitTx.txid || !commitTx.commitUTXO) {
            throw new Error(`Commit TX failed: ${commitTx.error}`);
        }

        const utxo: IUTXO = {
            ...commitTx.commitUTXO,
            txid: commitTx.txid,
            scriptPubKey: this.multySigChannelData.scriptPubKey,
            redeemScript: this.multySigChannelData.redeemScript
        };

        this.socketService.send(
            `${this.myInfo.socketId}::swap`, 
            new SwapEvent('SELLER:STEP3', this.myInfo.socketId, utxo).toJSON()
        );
        
    } catch (err: any) {
        this.terminateTrade(`Step 2: ${err.message}`);
    }
}

private isSpotZeroTrade(): boolean {
  if (this.typeTrade !== ETradeType.SPOT) return false;

  // Prefer the top-level shape you showed
  if ('propIdDesired' in (this.tradeInfo as any) && 'propIdForSale' in (this.tradeInfo as any)) {
    const { propIdDesired, propIdForSale } = this.tradeInfo as any;
    return Number(propIdDesired) === 0 || Number(propIdForSale) === 0;
  }
  return false
}

    private async onStep4(cpId: string, psbtHex: string, commitTxId?: string) {
        this.logTime('Step 4 Start');
        try {
            if (cpId !== this.cpInfo.socketId) throw new Error('Step 4: p2p mismatch');
            if (!psbtHex) throw new Error('Step 4: missing PSBT');
            
            const skipRbf = this.isSpotZeroTrade();
            if (commitTxId && !skipRbf) {
                const baseUrl = this.relayerUrl
                const txRes = await axios.get(`{$baseUrl}/tx/${commitTxId}?verbose=true`);
                const vins = txRes?.data?.vin || [];
                const isRbf = vins.some((vin: any) => vin.sequence < 0xfffffffe);
                if (isRbf) throw new Error('RBF-enabled commit tx detected');
            }

            const signRes = await this.txsService.signPsbt(psbtHex,true);
            if (signRes.error || !signRes.data?.psbtHex) throw new Error(`PSBT sign failed: ${signRes.error}`);

            this.socketService.send(`${this.myInfo.socketId}::swap`, new SwapEvent('SELLER:STEP5', this.myInfo.socketId, signRes.data.psbtHex).toJSON());
        } catch (err: any) {
            this.terminateTrade(`Step 4: ${err.message}`);
        }
    }

    private async onStep6(cpId: string, finalTx: string) {
        this.logTime('Step 6 Start');
        if (cpId !== this.cpInfo.socketId) return this.terminateTrade('Step 6: p2p mismatch');
        this.toastrService.info(`Trade complete: ${finalTx}`);
        if (this.readyRes) this.readyRes({ data: { txid: finalTx, seller: true, trade: this.tradeInfo } });
        this.removePreviuesListeners();
    }
}
