declare module 'bitcore-lib-litecoin' {
    const bitcore: any;
    export = bitcore;
}
