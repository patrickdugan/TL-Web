import { ENDPOINTS } from "./endpoints.conf";
export const environment = {
  production: true,
  apiBase: '/api',       // or your deployed API URL
  algoDefaults: true,
  homeApiUrl: "http://localhost:1986",
  ENDPOINTS,
};
