export const safeNumber = (a: number, d: number = 6) => parseFloat((a).toFixed(d));
